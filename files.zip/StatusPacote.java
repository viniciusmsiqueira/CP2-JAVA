/**
 * Enumeração dos possíveis status de um pacote no sistema FiapDelivery.
 *
 * <p>Usar um enum garante que apenas valores válidos sejam atribuídos ao status,
 * eliminando o risco de strings arbitrárias como era feito no código legado.</p>
 *
 * @author Aluno FIAP
 * @version 1.0
 */
public enum StatusPacote {

    /** Pacote registrado, aguardando coleta. */
    PENDENTE,

    /** Pacote em trânsito com o veículo de entrega. */
    EM_TRANSITO,

    /** Pacote entregue com sucesso ao destinatário. */
    ENTREGUE,

    /** Entrega não foi concluída por algum motivo. */
    CANCELADO
}
